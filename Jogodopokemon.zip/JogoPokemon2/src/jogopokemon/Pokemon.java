/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jogopokemon;

import javax.swing.JOptionPane;

/**
 *
 * @author marco
 */
public class Pokemon {
   private String nome;   
   private String tipo;

    
   private int level;
   private int vida = 1000;
   private int ataque;
   private int defesa;
   
   public Pokemon(String nome, String tp, int level){
       this.nome = nome;
       this.tipo = tp;
       this.level = level;
       calculaAtributos(tp);
       calculaBonus();
       
   }
   
   private void calculaAtributos(String tp){
       //Criação dos tipos de pokemon
       
       if(tp.equalsIgnoreCase("fogo")){
           this.vida -= 80;
           this.ataque = 75;
           this.defesa = 10;
       }else if(tp.equalsIgnoreCase("agua")){
           this.vida -= 50;
           this.ataque = 65;
           this.defesa = 50;
       }else if(tp.equalsIgnoreCase("planta")){
           this.vida += 40;
           this.ataque = 25;
           this.defesa = 30;
       }else if(tp.equalsIgnoreCase("pedra")){
           this.vida += 10;
           this.ataque = 45;
           this.defesa = 80;
       }
   }
   
   public void calculaBonus(){
       this.vida += (this.level/4);
       this.ataque += (this.level/2);
       this.defesa += (this.level/3);
   }
   
   public void imprimePokemon(){
       JOptionPane.showMessageDialog(null, "Nome: " + this.nome +
               ", tipo: " + this.tipo + ", level: " + this.level);
       JOptionPane.showMessageDialog(null, "Vida: " + this.vida +
               ", ataque: " + this.ataque + ", defesa: " + this.defesa);
   }
   
   
    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getDefesa() {
        return defesa;
    }
    public String getTipo() {
        return tipo;
    }

    public int getLevel() {
        return level;
    }

}
