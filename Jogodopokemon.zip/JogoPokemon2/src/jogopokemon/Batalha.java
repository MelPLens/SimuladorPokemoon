/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jogopokemon;

import javax.swing.JOptionPane;

/**
 *
 * @author marco
 */
public class Batalha {

    
    private String meuPokemonNome;
    private int meuPokemonVida, meuPokemonAtaque, meuPokemonDefesa;
    
    private String outroPokemonNome;
    private int outroPokemonVida, outroPokemonAtaque, outroPokemonDefesa;

    public Batalha(Pokemon poke1, Pokemon poke2) {
      meuPokemonNome = poke1.getNome();
      meuPokemonVida = poke1.getVida();
      meuPokemonAtaque = poke1.getAtaque();
      meuPokemonDefesa = poke1.getDefesa();
      
      outroPokemonNome = poke2.getNome();
      outroPokemonVida = poke2.getVida();
      outroPokemonAtaque = poke2.getAtaque();
      outroPokemonDefesa = poke2.getDefesa();
      
      startBattle();
      
    }

    
    public void meuPokemon(String nome, int vida) {
        meuPokemonNome = nome;
        meuPokemonVida = vida;
    }

    public void outroPokemon(String nome, int vida) {
        outroPokemonNome = nome;
        outroPokemonVida = vida;
    }
    
     

    public void startBattle() {
        if(meuPokemonVida > outroPokemonVida ){
            JOptionPane.showMessageDialog(null, "Meu pokemon venceu");
        }else if(meuPokemonVida < outroPokemonVida ){
            JOptionPane.showMessageDialog(null, "Pokemon do oponente venceu");
        }
    }
}

